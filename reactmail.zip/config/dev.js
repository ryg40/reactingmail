// dev.js - dont commit
module.exports = {
    googleClientID: '359488684942-oh6blvlt4pkjo3hkg98gcjc2gv0o2cdr.apps.googleusercontent.com',
    googleClientSecret: 'OSZ9UsJ5R0VIKPYLb3IiW_br',
    mongoURI: 'ryan:stayonx12@54.236.10.106:27017/emaily-dev',
    cookieKey: 'hdkhdlwkhdawlkdhawlkdhawldhlawedwa',
    stripePublishableKey: 'pk_test_oD1kNUB7BDYnoVkyOIAHNXBo',
    stripeSecretKey: 'sk_test_6k4ewFaZPRQJeAPogPlbwkos'
};